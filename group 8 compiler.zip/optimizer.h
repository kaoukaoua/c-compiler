// optimizer.h
#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include "parser.h"

ASTNode* optimize(ASTNode* node);

#endif
