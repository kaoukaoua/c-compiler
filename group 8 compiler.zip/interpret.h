#ifndef INTERPRET_H
#define INTERPRET_H

#include "parser.h"

int interpret(ASTNode* node);

#endif
