#!/bin/bash
gcc -o main main.c